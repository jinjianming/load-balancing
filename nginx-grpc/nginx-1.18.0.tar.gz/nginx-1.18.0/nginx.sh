#!/bin/bash 

case $1 in
   start)
          ./sbin/nginx -c conf/nginx.conf
           ;;
    stop)  # 服务停止需要做的步骤
           ./sbin/nginx -s quit 
           ;;
   restart) # 重启服务需要做的步骤
            ./sbin/nginx -s reload
            ;;

          *) echo "$0 {start|stop|restart}"
             exit 4
             ;;
esac
